loadstring(game:GetObjects("rbxassetid://418957341")[1].Source)()


Decompile:saveinstance(game.ReplicatedStorage.Model, "name")